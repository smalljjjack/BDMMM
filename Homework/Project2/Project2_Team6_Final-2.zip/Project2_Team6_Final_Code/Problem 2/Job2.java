import java.io.IOException;
import java.util.*;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;
import org.apache.hadoop.mapreduce.lib.input.LineRecordReader;
import org.apache.hadoop.mapreduce.lib.input.NLineInputFormat;
import org.apache.hadoop.util.LineReader;


public class Job2{
	public static class Job2Mapper extends Mapper<Object, Text, Text, Text>{
		//Map job group data based on the records of Elevation
		public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
			String json = value.toString();
			String[] jsonData =json.split(",");
			context.write(new Text("Elevation: "+jsonData[8].split(":")[1]), new Text("1"));
		}
	}

	public static class Job2Reducer extends Reducer<Text, Text, Text, Text>{
		// Reduce do the count Job
		public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException{
			int count = 0;
			for(Text val : values) count++;
			context.write(key, new Text(Integer.toString(count)));
		}
	}

	public static void main(String[] args) throws Exception{
		Configuration conf = new Configuration();
	    Job job = new Job(conf, "Test");
	    job.setJarByClass(Job2.class);
	    job.setMapperClass(Job2Mapper.class);
	    job.setReducerClass(Job2Reducer.class);
	    job.setInputFormatClass(JSONReader.JSONInputFormat.class);
	    job.setOutputKeyClass(Text.class);
	    job.setOutputValueClass(Text.class);
	    FileInputFormat.addInputPath(job, new Path("/user/hadoop/input/Project2/airfield.txt"));
	    FileOutputFormat.setOutputPath(job, new Path(args[0]));

	    System.exit(job.waitForCompletion(true) ? 0 : 1);
	}	 
}